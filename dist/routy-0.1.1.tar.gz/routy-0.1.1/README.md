# Routy

## Comparing routing algorithms made easy

Ever worked on your reinforcement learning routing algorithm and wondered how on earth it is performing? How do you convince someone you are actually providing a better solution than their existing heuristics?

Routy is the library to help you do exactly that.
 
 
 

## Installation

Install your library.

```sh
pip install routy
```
